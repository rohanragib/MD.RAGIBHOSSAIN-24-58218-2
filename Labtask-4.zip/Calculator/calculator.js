let display = document.getElementById("display");
let operator = "";


function appendValue(value) {

    display.value = display.value + value;

}


function setOperator(op) {

    
    if (display.value == "" || operator != "") {
        return;
    }

    operator = op;

    display.value = display.value + op;

}


function clearDisplay() {

    display.value = "";

    operator = "";

}


function deleteLast() {

    let text = display.value;

    let last = text.substring(text.length - 1);

    
    if (last == operator) {
        operator = "";
    }

    display.value = text.substring(0, text.length - 1);

}


function calculate() {

    if (operator == "") {
        return;
    }

    let parts = display.value.split(operator);

    if (parts[1] == "") {
        return;
    }

    let num1 = parseFloat(parts[0]);
    let num2 = parseFloat(parts[1]);
    let result = 0;

    if (operator == "+") {
        result = num1 + num2;
    }
    else if (operator == "-") {
        result = num1 - num2;
    }
    else if (operator == "x") {
        result = num1 * num2;
    }
    else if (operator == "/") {

        if (num2 == 0) {
            display.value = "Error";
            operator = "";
            return;
        }

        result = num1 / num2;
    }

    display.value = Math.round(result * 1000000) / 1000000;

    operator = "";

}
